# jQuery Center Plugin CHANGELOG

## 1.1.1/ 2012-10-31

- [bug fix] center against window failed



## 1.1.0

* Add center on window resize option, default to true



## 1.0.3

* Add package.json for new jquery plugin site



## 1.0.2

* Fix bug on undefined variable against ( thanks to Nick Inhofe )



## 1.0.1

* Fix jQuery conflict



## 1.0.0

* First stable release